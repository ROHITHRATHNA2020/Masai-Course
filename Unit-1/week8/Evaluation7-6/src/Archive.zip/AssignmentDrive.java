import java.util.Scanner;

public class AssignmentDrive {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String name = scanner.next();
        String Link = scanner.next();
        String assignmentPassword = scanner.next();
        int questions = scanner.nextInt();

        Assignment assignment = new Assignment() {
            @Override
            public void setAssignmentName(String assignmentName) {
                setAssignmentName(name);
            }

            @Override
            public void setAssignmentLink(String link) {
                setAssignmentLink(Link);
            }

            @Override
            public void privasetAssignmentPassword(String password) {
                privasetAssignmentPassword(assignmentPassword);
            }

            @Override
            public void setnoOfQuestions(int noOfQuestions) {
                setNoOfQuestions(questions);
            }

        };
        System.out.println(assignment.getAssignmentName());
        System.out.println(assignment.getAssignmentLink());
        System.out.println(assignment.getAssignmentPassword());
        System.out.println(assignment.getNoOfQuestions());
    }
}
