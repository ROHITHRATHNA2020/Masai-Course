public abstract class FTAND extends Assignment {
    private String batchName;

    public void  setBatchName(String batchName){

    }

    public String getBatchName() {
        return batchName;
    }

    public void display(){
        System.out.println("The Assignment Name is "+getAssignmentName() );
        System.out.println("The Assignment Link is  " +getAssignmentLink());
        System.out.println("The Assignment Password is " +getAssignmentPassword());
        System.out.println("Total number of questions are " );
        System.out.println("Batch Name is FTAND-03"+getBatchName());

    }
}
