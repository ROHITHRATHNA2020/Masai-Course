public abstract class Assignment {
    private String assignmentName;
    private String assignmentLink;
    private String assignmentPassword;
    private int noOfQuestions;

    public String getAssignmentName() {
        return assignmentName;
    }

    public String getAssignmentLink() {
        return assignmentLink;
    }

    public String getAssignmentPassword() {
        return assignmentPassword;
    }

    public void setAssignmentPassword(String assignmentPassword) {
        this.assignmentPassword = assignmentPassword;
    }

    public int getNoOfQuestions() {
        return noOfQuestions;
    }

    public void setNoOfQuestions(int noOfQuestions) {
        this.noOfQuestions = noOfQuestions;
    }

    public abstract void setAssignmentName(String assignmentName);

    public abstract void setAssignmentLink(String link);

    public abstract  void privasetAssignmentPassword(String password);

    public abstract void setnoOfQuestions(int noOfQuestions);

}
