public class Ternery {
    public static void main(String[] args) {
        int a=10;
        int b=11;
        String result=(a>b)?"a is greater":"b is greater";
        System.out.println(result);
    }
}
