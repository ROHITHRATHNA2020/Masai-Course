public class Student {

    String name;
     String DOB;
     String blood_Group;

    public Student(String name,String DOB,String blood_Group){
        this.name= name;
        this.DOB=DOB;
        this.blood_Group=blood_Group;
    }


}
