public class KFC {
    public final void friedChickenRecipe(){
        System.out.println("Fried Chicken recipe: Take 200gms boneless chicken  and marinate it with lemon, salt and flour");
    }
    public void display(){
        System.out.println("KFC token number is 102");
    }
}
