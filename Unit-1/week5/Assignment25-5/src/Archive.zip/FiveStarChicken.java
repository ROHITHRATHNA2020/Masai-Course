public class FiveStarChicken extends KFC{
    @Override
    public void display() {
        System.out.println("FiveStarChicken token number is 345");
    }

}
