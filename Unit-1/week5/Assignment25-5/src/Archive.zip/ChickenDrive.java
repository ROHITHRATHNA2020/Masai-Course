public class ChickenDrive {
    public static void main(String[] args) {
        KFC kfc= new KFC();
        kfc.friedChickenRecipe();
        kfc.display();
        System.out.println();
        FiveStarChicken f = new FiveStarChicken();
        f.display();

    }
}
