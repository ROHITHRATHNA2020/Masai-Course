public class Shape {


    public void calculatePerimeter(){

    }
    public void calculateArea(){

    }
}
