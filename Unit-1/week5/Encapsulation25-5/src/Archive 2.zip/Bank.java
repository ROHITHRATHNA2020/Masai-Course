public class Bank {
    String name;
    int balance;

    public Bank(String name,int balance){
        this.name=name;
        this.balance=balance;
    }

    public String getName() {
        return name;
    }

    public int getBalance() {
        return balance;
    }
}
